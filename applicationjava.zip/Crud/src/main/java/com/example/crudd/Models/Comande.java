package com.example.crudd.Models;

import java.util.Date;

public class Comande {
    private int id_comande ;
    private String date_comande ;
    private String mantant_comande ;
    private int Id_cli ;

    public Comande() {
    }

    public Comande(int id_comande, String date_comande, String mantant_comande, int id_cli) {
        this.id_comande = id_comande;
        this.date_comande = date_comande;
        this.mantant_comande = mantant_comande;
        this.Id_cli = id_cli;
    }

    public void setId_comande(int id_comande) {
        this.id_comande = id_comande;
    }
    public void setDate_comande(String date_comande) {
        this.date_comande = date_comande;
    }

    public void setMantant_comande(String mantant_comande) {
        this.mantant_comande = mantant_comande;
    }

    public void setId_cli(int id_cli) {
        Id_cli = id_cli;
    }

    public int getId_comande() {
        return id_comande;
    }

    public String getDate_comande() {
        return date_comande;
    }

    public String getMantant_comande() {
        return mantant_comande;
    }

    public int getId_cli() {
        return Id_cli;
    }

    @Override
    public String toString() {
        return "Comande{" +
                "id_commande=" + id_comande +
                ", date_commande='" + date_comande + '\'' +
                ", mantant_commande='" + mantant_comande + '\'' +
                ", Id_cli=" + Id_cli +
                '}';
    }
}

package com.example.crudd.Control;

import com.example.crudd.Models.Comande;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class comandeControl {
    public void insertComande(Comande commande) throws SQLException {
        Statement statement;
        statement=Connexion.onConnection().createStatement();
        statement.executeUpdate("INSERT INTO `commande`(`id_comande`, `date_comande`, `mantant_comande`, `id_cli`) VALUES ('"+commande.getId_comande()+"','"+commande.getDate_comande()+"','"+commande.getMantant_comande()+"','"+commande.getId_cli()+"')");
        Connexion.closeConnection();
    };

    public void modifierComande(Comande commande) throws SQLException{
        Statement statement;
        statement = Connexion.onConnection().createStatement();
        statement.executeUpdate("UPDATE `commande` SET `mantant_comande`='"+commande.getMantant_comande()+"' WHERE id_comande='"+commande.getId_comande()+"'");
        Connexion.closeConnection();
    };

    public void SupprimerComande(int id)throws SQLException{
        Statement statement;
        statement=Connexion.onConnection().createStatement();
        statement.executeUpdate("DELETE FROM `commande` WHERE id_comande ='"+id+"'");
        Connexion.closeConnection();
    }

    public ObservableList<Comande> getAllComande() throws SQLException{
        ObservableList list= FXCollections.observableArrayList();
        Statement statement ;
        statement=Connexion.onConnection().createStatement();
        ResultSet result = statement.executeQuery("SELECT * FROM `commande`");
        while (result.next()){
            Comande commande=new Comande() ;
            commande.setId_comande(result.getInt("id_comande"));
            commande.setDate_comande(result.getString("date_comande"));
            commande.setMantant_comande(result.getString("mantant_comande"));
            commande.setId_cli(result.getInt("id_cli"));
            list.add(commande);
        }
        Connexion.closeConnection();
        return list ;
    }

}

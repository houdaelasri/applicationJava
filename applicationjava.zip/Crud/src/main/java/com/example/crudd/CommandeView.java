package com.example.crudd;

import com.example.crudd.Control.clientControl;
import com.example.crudd.Control.comandeControl;
import com.example.crudd.Models.Client;
import com.example.crudd.Models.Comande;
import com.example.crudd.Models.Credit;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CommandeView implements Initializable {
    @FXML
    private Button btnClient;
    @FXML
    private Button btnCredit;
    @FXML
    private Button btnProduit;

    @FXML
    private Button btnCommande;
    @FXML
    private Button btn_ajouter;

    @FXML
    private Button btn_modifier;

    @FXML
    private Button btn_supprimer;

    @FXML
    private TableColumn date;

    @FXML
    private TextField date_comande;

    @FXML
    private TableColumn id;

    @FXML
    private TextField id_comande;
    @FXML
    private TableColumn id_cli;

    @FXML
    private TextField id_cli_comande;
    @FXML
    private TableColumn montanet;

    @FXML
    private TextField mantant_comande;

    @FXML
    private TableView table;

    public void  onclikClient(Event se) throws SQLException, IOException {
        Node node=(Node)se.getSource();

        Stage stage =(Stage) node.getScene().getWindow();
        Parent route = FXMLLoader.load(getClass().getResource("Client.fxml"));
        Scene scene = new Scene(route);
        stage.setTitle("client!");
        stage.setScene(scene);
        stage.show();

    }
    public void  onclikProduit(Event se) throws SQLException, IOException {
        Node node=(Node)se.getSource();

        Stage stage =(Stage) node.getScene().getWindow();
        Parent route = FXMLLoader.load(getClass().getResource("Produit.fxml"));
        Scene scene = new Scene(route);
        stage.setTitle("produit!");
        stage.setScene(scene);
        stage.show();

    }
    public void  onclikCredit(Event se) throws SQLException, IOException {
        Node node=(Node)se.getSource();

        Stage stage =(Stage) node.getScene().getWindow();
        Parent route = FXMLLoader.load(getClass().getResource("Credit.fxml"));
        Scene scene = new Scene(route);
        stage.setTitle("credit!");
        stage.setScene(scene);
        stage.show();
    }
    public void  onclikCommande(Event se) throws SQLException, IOException {
        Node node=(Node)se.getSource();

        Stage stage =(Stage) node.getScene().getWindow();
        Parent route = FXMLLoader.load(getClass().getResource("Commande.fxml"));
        Scene scene = new Scene(route);
        stage.setTitle("commande!");
        stage.setScene(scene);
        stage.show();
    }
    comandeControl comandeControl =new comandeControl() ;
    public void ShowB(){
        id.setCellValueFactory(new PropertyValueFactory<Client,Integer>("id_comande"));
        date.setCellValueFactory(new PropertyValueFactory<Client,String>("date_comande"));
        montanet.setCellValueFactory(new PropertyValueFactory<Client,String>("mantant_comande"));
        id_cli.setCellValueFactory(new PropertyValueFactory<Client,String>("id_cli"));
        try {
            table.setItems(comandeControl.getAllComande());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    };
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ShowB();
    }

    public void AjouteCo(Event e) throws SQLException{
        Comande commande =new Comande();
        commande.setId_comande(Integer.valueOf(id_comande.getText()));
        commande.setDate_comande(date_comande.getText());
        commande.setMantant_comande(mantant_comande.getText());
        commande.setId_cli(Integer.valueOf(id_cli_comande.getText()));
        comandeControl.insertComande(commande);
        ShowB();
        id_comande.setText("");
        date_comande.setText("");
        id_cli_comande.setText("");
        mantant_comande.setText("");
    }
    public void ModifierCo(Event e) throws SQLException {
        Comande commande =new Comande();
        commande.setId_comande(Integer.valueOf(id_comande.getText()));
        commande.setDate_comande(date_comande.getText());
        commande.setMantant_comande(mantant_comande.getText());
        commande.setId_cli(Integer.valueOf(id_cli_comande.getText()));
        comandeControl.modifierComande(commande);
        ShowB();
        id_comande.setText("");
        date_comande.setText("");
        id_cli_comande.setText("");
        mantant_comande.setText("");
    }
    int ID ;
    public void ClickTable3(Event e){
        Comande commande =(Comande) table.getSelectionModel().getSelectedItem();
        id_comande.setText(String.valueOf(commande.getId_comande()));
        date_comande.setText(commande.getDate_comande());
        mantant_comande.setText(commande.getMantant_comande());
        id_cli_comande.setText(String.valueOf(commande.getId_cli()));
        ID= commande.getId_comande();
    }
    public void SuppCo(Event e) throws SQLException {
        comandeControl.SupprimerComande(ID);
        ShowB();
        id_comande.setText("");
        date_comande.setText("");
        id_cli_comande.setText("");
        mantant_comande.setText("");
    }
}

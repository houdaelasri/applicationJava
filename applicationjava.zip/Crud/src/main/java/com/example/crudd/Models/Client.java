package com.example.crudd.Models;

public class Client {
    private Integer id ;
    private String nom;
    private String telephone;
    private String adresse;

    public Client() {
    }

    public Client(int id ,String nom, String telephone, String adresse) {
        this.id = id ;
        this.nom = nom;
        this.telephone = telephone;
        this.adresse = adresse;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setTELE(String telephone) {
        this.telephone = telephone;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public int getId() {
        return id;
    }
    public String getNom() {
        return nom;
    }

    public String getTELE() {
        return telephone;
    }

    public String getAdresse() {
        return adresse;
    }

    @Override
    public String toString() {
        return "Client{" +
                "Nom='" + nom + '\'' +
                ", TELE=" + telephone +
                ", adresse='" + adresse + '\'' +
                '}';
    }
}

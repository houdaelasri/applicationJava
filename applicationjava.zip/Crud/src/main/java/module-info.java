module com.example.crudd {
    requires javafx.controls;
    requires javafx.fxml;
            
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;

    opens com.example.crudd to javafx.fxml;
    exports com.example.crudd;
    opens com.example.crudd.Models to javafx.xml;
    exports com.example.crudd.Models;
}